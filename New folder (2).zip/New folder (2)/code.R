
#====================================part1======================================

# image analysis  
install.packages("magick")   
library(magick)  

# Step 1: Load the image  
image <- image_read("C:/Users/HP/OneDrive/Desktop/photo.jpg")  
print(image)  

# Step 2: Resize the image  
image <- image_scale(image, "450")  
image <- image_scale(image, "x350") 
# Alternatively, use:  

# Step 3: Add a blue background and border  
image_with_background <- image_background(image, "black")
image_with_border <- image_border(image_with_background, "#000100", "34x34") 
# Step 4: Annotate the image with text  
image_annotated <- image_annotate(image_with_border,   
                                  "setareh gholami",   
                                  size = 30,   
                                  gravity = "southwest",   
                                  color = "white")  

# Step 5: Display the modified image  
print(image_annotated)  

# Optional: Save the annotated image  
image_write(image_annotated, "C:/Users/HP/OneDrive/Desktop/annotated_image.jpg")


#====================================part2======================================


install.packages('readr')  # Install readr package if it's not already installed  
library(igraph)  
library(readr)  

# Load data from the specified CSV file  
file_path <- "C:/Users/HP/OneDrive/Desktop/data.csv"  
data <- read_csv(file_path, col_names = FALSE)  # No headers assumed  

# Check the first few rows of data to confirm the structure  
print(head(data))  

# Convert the data frame into an edge list, assuming two columns (source, target)  
edges <- as.matrix(data)  

# Create the graph  
net <- graph_from_edgelist(edges, directed = TRUE)  

# Assign labels to vertices  
V(net)$label <- V(net)$name  

# Compute the degree of each vertex  
V(net)$degree <- degree(net)  

# Check the structure of the graph  
cat(paste("Vertices:", vcount(net), "Edges:", ecount(net)), "\n")  

# Plotting the network  
set.seed(222)  # For reproducibility  

# Set the plotting area size for a larger graph  
options(repr.plot.width=15, repr.plot.height=10)  

# Plot the network  
plot(net,  
     vertex.color = 'yellow',  
     vertex.size = V(net)$degree *3,  # Adjust size based on degree  
     edge.arrow.size = 0.6,  
     vertex.label.cex = 0.8,  # Adjust label size if needed  
     layout = layout.fruchterman.reingold)  







# نصب بسته‌های مورد نیاز و بارگذاری آن‌ها  
install.packages('readr')  # نصب بسته readr در صورت نیاز  
library(igraph)  
library(readr)  

# بارگذاری داده‌ها از فایل CSV  
file_path <- "C:/Users/HP/OneDrive/Desktop/data.csv"  
data <- read_csv(file_path, col_names = FALSE)  # فرض بر این است که هیچ عنوانی وجود ندارد  

# تبدیل فریم داده به یک لیست کناری  
edges <- as.matrix(data)  

# ایجاد گراف  
net <- graph_from_edgelist(edges, directed = TRUE)  

# تخصیص برچسب به رئوس  
V(net)$label <- V(net)$name  

# محاسبه درجه هر رأس  
V(net)$degree <- degree(net)  

# بررسی ساختار گراف  
cat(paste("Vertices:", vcount(net), "Edges:", ecount(net)), "\n")  

# تنظیم حالت تصادفی برای تولیدپذیری  
set.seed(222)  # برای تولید مجدد  

# ذخیره گراف به عنوان یک تصویر  
png("C:/Users/HP/OneDrive/Desktop/network_plot.png", width = 1500, height = 1000)  
plot(net,  
     vertex.color = 'yellow',  
     vertex.size = V(net)$degree * 3.7,  # تنظیم اندازه بر اساس درجه  
     edge.arrow.size = 1.5,  
     vertex.label.cex = 2,  # تنظیم اندازه برچسب در صورت نیاز  
     layout = layout.fruchterman.reingold)  
dev.off()  # بستن تصویر



#====================================part3======================================

# Load necessary libraries  
if (!requireNamespace("tm", quietly = TRUE)) install.packages("tm")  
if (!requireNamespace("wordcloud2", quietly = TRUE)) install.packages("wordcloud2")  
if (!requireNamespace("png", quietly = TRUE)) install.packages("png")  

library(tm)  
library(wordcloud2)  
library(png)  

# Step 1: Read the text data from the file path  
text <- readLines("C:/Users/HP/OneDrive/Desktop/tex.txt")  

# Step 2: Create a corpus from the text data  
docs <- Corpus(VectorSource(text))  

# Step 3: Preprocess the text data  
docs <- tm_map(docs, content_transformer(tolower))  
docs <- tm_map(docs, removeNumbers)  
docs <- tm_map(docs, removeWords, stopwords("english"))  
docs <- tm_map(docs, removePunctuation)  
docs <- tm_map(docs, stripWhitespace)  

# Step 4: Create a Term-Document Matrix (TDM)  
dtm <- TermDocumentMatrix(docs)  
m <- as.matrix(dtm)  

# Step 5: Calculate the frequency of words  
word_freqs <- sort(rowSums(m), decreasing = TRUE)  
word_freqs_df <- data.frame(word = names(word_freqs), freq = word_freqs)  

# If you want to use a custom mask image (e.g., an eye shape):  
# Load the mask image  
mask_img <- readPNG("C:/Users/HP/OneDrive/Desktop/eye.png")  

# Step 6: Create the Word Cloud and save it as HTML  
wordcloud2(word_freqs_df,  
           size = 0.5,                # Size of words  
           color = "random-dark",     # Word color  
           backgroundColor = "black", # Background color  
           shape = "star")          # Use a shape, e.g., circle  

# To save the Word Cloud as an HTML file, use saveWidget from htmlwidgets  
library(htmlwidgets)  
saveWidget(wordcloud2(word_freqs_df,  
                      size = 0.5,  
                      color = "random-dark",  
                      backgroundColor = "black",   
                      shape = "star"),  
           file = "C:/Users/HP/OneDrive/Desktop/wordcloud.html")




